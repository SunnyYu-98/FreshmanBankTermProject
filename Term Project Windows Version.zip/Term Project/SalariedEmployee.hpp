//
//  SalariedEmployee.hpp
//  Term Project
//
//  Created by Sunny Irving Yu on 4/24/17.
//  Copyright © 2017 Sunny Irving Yu. All rights reserved.
//

#ifndef SalariedEmployee_hpp
#define SalariedEmployee_hpp

#include <stdio.h>

#endif /* SalariedEmployee_hpp */
