//
//  SalariedCommissionEmployee.h
//  Term Project
//
//  Created by Sunny Irving Yu on 4/24/17.
//  Copyright © 2017 Sunny Irving Yu. All rights reserved.
//

#ifndef SalariedCommissionEmployee_h
#define SalariedCommissionEmployee_h


#endif /* SalariedCommissionEmployee_h */
